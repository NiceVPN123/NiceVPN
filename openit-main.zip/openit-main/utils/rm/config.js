module.exports={
    nodeAddName:' → openitsub.com',
    dnsServers:['223.5.5.5','114.114.114.114']
}
